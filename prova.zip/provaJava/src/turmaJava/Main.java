package turmaJava;

public class Main {
	
	public static void main(String[] args) {
		Salas sala = new Salas();
		Pessoa p = new Pessoa();
		p.Pessoa2();
		sala.SalasT();
		sala.cadastroSalaCafe();
	}

}
