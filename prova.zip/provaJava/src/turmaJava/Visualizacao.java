package turmaJava;

public interface Visualizacao {
	void Pessoa2();
	void SalasT();
	void cadastroSalaCafe();
	}
