package turmaJava;

public class EspacoCafe {
	String nome;

	public String getLotacao() {
		return nome;
	}

	public void setLotacao(String nome) {
		this.nome = nome;
		
	}
	
	

}
